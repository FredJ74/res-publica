async function doVendreMatiereCommerce(commerceType, buildingId, roomId, pa, cost) {
  const pays = state.country || 'republic';
  const ville = state.currentCity || 'capitale';
  const personnage = state.char?.name;
  const data = await chargerCommerce(commerceType, pays, ville, buildingId, roomId);
  if (state.country !== pays || state.currentCity !== ville ||
      state.currentBuilding !== buildingId || state.char?.name !== personnage ||
      (roomId && state.currentRoom !== roomId)) return;
  if (!data) {
    showToast('Commerce injoignable', "Les informations de ce commerce n'ont pas pu être chargées. Réessayez dans un instant.", false);
    return;
  }
  const cur = COUNTRIES[pays]?.cur || 'FR';
  const matieres = matieresAccepteesParCommerce(data);
  document.getElementById('postes-modal-title').textContent = 'Vendre des matières au commerce';
  let html = '<div style="padding:1rem">';
  html += '<div style="font-size:.82rem;color:#8a8060;margin-bottom:.7rem">Stock et prix d\'achat pratiqués par ce commerce. Vous pouvez consulter ces informations sans posséder de matières premières.</div>';
  if (!matieres.length) html += '<div style="font-size:.9rem;color:#8a8060">Aucune matière première achetée actuellement.</div>';
  matieres.forEach(m => {
    const qteDispo = (state.inventory || []).filter(i => i.stackKey === m && (i.qty || 0) > 0)
      .reduce((total,i) => total + Number(i.qty || 0), 0);
    const prixUnitaire = prixAchatMatiereCommerce(data, m);
    const stockMax = plafondEffectifCommerce(data, m);
    const stockActuel = Number(data.stockMatieres?.[m] || 0);
    const placeRestante = Math.max(0, stockMax - stockActuel);
    const label = (typeof RESSOURCES_ECONOMIE !== 'undefined' && RESSOURCES_ECONOMIE[m]) ? RESSOURCES_ECONOMIE[m].label : m;
    const vendable = Math.min(qteDispo, placeRestante);
    html += '<div style="padding:.65rem;border:1px solid #455365;margin-bottom:.65rem">';
    html += '<div style="font-size:.92rem;color:#c0b090;font-weight:bold">Stock ' + label + ' : ' + stockActuel + '/' + stockMax + '</div>';
    html += '<div style="font-size:.84rem;color:#a9b7c9;margin:.3rem 0">Prix d\'achat : ' + prixUnitaire.toLocaleString('fr-FR') + ' ' + cur + ' / unité — Vous en possédez : ' + qteDispo + '</div>';
    html += '<div style="display:flex;align-items:center;gap:.5rem;flex-wrap:wrap">';
    html += '<label for="vendre-commerce-qte-' + m + '" style="font-size:.83rem;color:#c0b090">Quantité à céder</label>';
    html += '<input type="number" id="vendre-commerce-qte-' + m + '" min="1" max="' + vendable + '" ' +
      (vendable <= 0 ? 'disabled value="" placeholder="—"' : 'value="' + vendable + '"') +
      ' style="width:76px;background:#202b39;border:1px solid #455365;color:#f0ead6;padding:.3rem;font-size:.88rem;outline:none"/>';
    const inactif = 'padding:.3rem .6rem;border:1px solid #455365;background:transparent;color:#667080;cursor:default;font-size:.82rem';
    html += '<button ' + (vendable <= 0 ? 'disabled style="' + inactif + '"' :
      'onclick="confirmerVendreMatiereCommerceUI(\'' + commerceType + '\',\'' + buildingId + '\',\'' + (roomId || '') + '\',\'' + m + '\',\'vente\')" style="padding:.3rem .6rem;border:1px solid #4a8a4a;background:transparent;color:#6ab858;cursor:pointer;font-size:.82rem"') + '>Vendre</button>';
    // Le don existant reste disponible, sans solliciter la caisse.
    html += '<button ' + (vendable <= 0 ? 'disabled style="' + inactif + '"' :
      'onclick="confirmerVendreMatiereCommerceUI(\'' + commerceType + '\',\'' + buildingId + '\',\'' + (roomId || '') + '\',\'' + m + '\',\'don\')" style="padding:.3rem .6rem;border:1px solid #6a5a20;background:transparent;color:#C9A84C;cursor:pointer;font-size:.82rem"') +
      ' title="Céder sans contrepartie. Ne prélève rien dans la caisse.">Donner</button>';
    html += '</div>';
    if (!qteDispo) html += '<div style="font-size:.78rem;color:#8a8060;margin-top:.4rem">Vous ne possédez pas cette matière.</div>';
    else if (!placeRestante) html += '<div style="font-size:.78rem;color:#8a8060;margin-top:.4rem">Le commerce a atteint sa limite d\'achat.</div>';
    html += '</div>';
  });
  html += '</div>';
  document.getElementById('postes-body').innerHTML = html;
  document.getElementById('modal-postes').classList.add('open');
}
async function confirmerVendreMatiereCommerceUI(commerceType, buildingId, roomId, matiere, mode) {
  const pays = state.country || 'republic';
  const ville = state.currentCity || 'capitale';
  const roomIdReel = roomId || null;
  // `don` ou `vente`. Ancien appel sans mode = vente, pour ne rien casser.
  const don = (mode === 'don');
  const qte = parseInt(document.getElementById('vendre-commerce-qte-' + matiere)?.value || '0');
  document.getElementById('modal-postes')?.classList.remove('open');
  if (!qte || qte <= 0) { showToast('Quantité invalide',
    'Indiquez un nombre entier d\'unités supérieur à zéro.', false); return; }

  const res = await vendreMatiereCommerce(commerceType, pays, ville, buildingId, roomIdReel, matiere, qte, don ? 'don' : 'vente');
  const label = (typeof RESSOURCES_ECONOMIE !== 'undefined' && RESSOURCES_ECONOMIE[matiere]) ? RESSOURCES_ECONOMIE[matiere].label : matiere;
  if (!res.ok) {
    // AUCUN REFUS SANS PHRASE. Trois entrees de cette table etaient des chaines
    // vides : le joueur voyait un bandeau muet et ne pouvait pas savoir si le
    // commerce refusait, si sa saisie etait fautive, ou si l'appel avait echoue.
    // Les trois etats de transport de sbRpcVerdict sont nommes ici pour la meme
    // raison -- ce ne sont pas des refus du commerce.
    // Un don refuse ne parle pas de vente : le geste refuse n'est pas le meme, et
    // « ce commerce n'achète pas cette matière » serait faux pour un cadeau.
    const acte = don ? 'le don' : 'la vente';
    const messages = {
      introuvable: 'Ce commerce est introuvable.',
      matiere_non_acceptee: don ? 'Ce commerce n\'a pas d\'usage de cette matière.'
                                : 'Ce commerce n\'achète pas cette matière.',
      quantite_invalide: 'Indiquez une quantité entière supérieure à zéro.',
      // On ne vend ni ne donne a distance : la marchandise se porte sur place.
      // Le serveur lit la position reelle, pas l'ecran affiche -- ce message
      // apparait donc aussi quand l'ecran est reste ouvert apres un deplacement.
      pas_sur_place: 'Il faut être dans ce commerce pour lui remettre des matières. Retournez-y et réessayez.',
      // INTERDICTION DE L'ASSEMBLEE, tranchee par le serveur. Le controle en amont
      // (assembleeControlerVenteLegale) evite d'arriver ici en jeu normal ; ce
      // message est la garantie, pas la politesse.
      matiere_interdite: 'Cette matière est interdite par la loi'
        + (res.loi && res.loi.titre ? ' « ' + res.loi.titre + ' »' : '')
        + ' : elle ne peut être ni vendue ni donnée.',
      mode_invalide: 'Cette opération n\'est pas reconnue par le serveur.',
      requete_invalide: 'Cette opération n\'a pas pu être identifiée. Réessayez.',
      parametres_invalides: 'Il manque une information pour identifier ce commerce.',
      personnage_introuvable: 'Votre personnage n\'a pas pu être identifié. Rechargez la page.',
      ressource_inconnue: 'Cette matière n\'a pas de prix de référence.',
      session_perdue: 'Votre session a expiré. Reconnectez-vous : ' + acte + ' n\'a pas eu lieu.',
      transport_indisponible: 'Le serveur n\'a pas répondu. ' + (don ? 'Le don' : 'La vente') + ' n\'a pas eu lieu.',
      reseau_indisponible: 'Connexion interrompue. ' + (don ? 'Le don' : 'La vente') + ' n\'a pas eu lieu.',
      stock_personnel_insuffisant: 'Vous n\'avez pas ' + qte + ' unité(s) de ' + label + '.',
      stock_plein: 'Le stock maximum de cette matière est atteint pour ce commerce.',
      caisse_insuffisante: 'Le commerce ne peut pas acheter cette quantité actuellement.'
    };
    // Un appel qui n'a pas abouti ne s'annonce pas comme un refus du commerce :
    // le titre change, parce que le geste a faire n'est pas le meme (se
    // reconnecter ou reessayer, plutot que revoir sa demande).
    const transport = ['session_perdue', 'transport_indisponible', 'reseau_indisponible'];
    const estTransport = transport.indexOf(res.raison) !== -1;
    if (estTransport) console.error('[commerce] vente de matiere non aboutie (transport)', res.raison);
    if (!res.dejaSignale) {
      const titre = estTransport ? (don ? 'Don non abouti' : 'Vente non aboutie')
                                 : (don ? 'Don refusé'    : 'Vente refusée');
      showToast(titre,
        messages[res.raison] || ('Le commerce a refusé ' + acte + ' (' + (res.raison || 'motif inconnu') + ').'),
        false);
    }
    return;
  }
  updateUI();
  if (don) {
    showToast('Don effectué', res.qte + ' ' + label + ' remis à ce commerce, sans contrepartie.', true, true);
    addJournalEntry('Don de ' + res.qte + ' ' + label + ' à ce commerce.', 'event-good');
  } else {
    showToast('Vente effectuée', '+' + res.total.toLocaleString('fr-FR') + ' FR pour ' + res.qte + ' ' + label + '.', true, true);
    addJournalEntry('Vente de ' + res.qte + ' ' + label + ' au commerce (+' + res.total.toLocaleString('fr-FR') + ' FR).', 'event-good');
  }
  doVendreMatiereCommerce(commerceType, buildingId, roomIdReel, 0, 0); // rafraichit, meme pattern que les autres interfaces de commerce
}
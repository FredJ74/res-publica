function doConsulterDossierNotarial() {
  document.getElementById('postes-modal-title').textContent = 'Se renseigner sur un dossier';
  let html = '<div style="padding:1rem">';
  html += '<div style="font-size:.82rem;color:#8a8060;margin-bottom:.8rem">Indiquez le nom du personnage dont vous souhaitez consulter les dossiers notariaux en cours.</div>';
  html += '<input id="dossier-notarial-nom" type="text" placeholder="Nom du personnage..." style="width:100%;background:#121005;border:1px solid #2a2010;color:#f0ead6;padding:.5rem .6rem;font-family:Crimson Pro,serif;font-size:.85rem;outline:none;margin-bottom:.6rem;box-sizing:border-box" />';
  html += '<button class="pnj-action-btn" onclick="rechercherDossierNotarial()"><i class="ti ti-search" style="font-size:.85rem"></i> Consulter</button>';
  html += '<div id="dossier-notarial-resultats" style="margin-top:.9rem"></div>';
  html += '</div>';
  document.getElementById('postes-body').innerHTML = html;
  document.getElementById('modal-postes').classList.add('open');
}
async function rechercherDossierNotarial() {
  const nom = (document.getElementById('dossier-notarial-nom')?.value || '').trim();
  const resultatsEl = document.getElementById('dossier-notarial-resultats');
  if (!resultatsEl) return;
  if (!nom) {
    resultatsEl.innerHTML = '<div style="font-size:.8rem;color:#8a3a20;font-style:italic">Indiquez un nom.</div>';
    return;
  }
  resultatsEl.innerHTML = '<div style="font-size:.8rem;color:#8a8060;font-style:italic">Recherche en cours...</div>';

  const dossiers = [];
  let lecturesEchouees = 0;

  // Terrains : compromis actif, achat direct (rendez-vous en attente), transfert de compromis
  // propose a ce nom -- meme source que doActeVenteTerrain/doOuvrirTransfertCompromis. Chaque
  // terrain est isole : une lecture qui echoue est journalisee et sautee, jamais fatale aux autres.
  if (typeof getTousLesTerrainsPays === 'function' && typeof chargerTerrainState === 'function' && typeof getTerrainState === 'function') {
    for (const id of getTousLesTerrainsPays()) {
      try {
        await chargerTerrainState(id);
        const ts = getTerrainState(id);
        if (!ts) continue;
        const nomBatiment = BUILDINGS[id]?.shortName || BUILDINGS[id]?.name || id;
        if (ts.compromis && ts.compromisPar === nom) {
          dossiers.push('Achat d\'un terrain (' + nomBatiment + ') — signature prévue avant le ' + formaterHorodatageJournal(ts.compromisExpireAt));
        }
        if (ts.achatDirect && ts.achatDirect.demandeur === nom) {
          dossiers.push('Achat direct d\'un terrain (' + nomBatiment + ') — rendez-vous notarial le ' + formaterHorodatageJournal(ts.achatDirect.dateAchat));
        }
        if (ts.transfertPropose === nom) {
          dossiers.push('Transfert de compromis proposé (' + nomBatiment + ') — en attente de validation');
        }
      } catch (e) {
        console.error('rechercherDossierNotarial : lecture terrain échouée', id, e);
        lecturesEchouees++;
      }
    }
  }

  // Entreprises : compromis de rachat actif -- meme source que doRachatEntreprise/doActeRachatEntreprise.
  // Meme isolation individuelle que les terrains ci-dessus.
  if (typeof getEntreprisesRachetables === 'function') {
    for (const def of getEntreprisesRachetables()) {
      try {
        const data = await def.charger();
        if (data && data.compromis && data.compromisPar === nom) {
          dossiers.push('Rachat de "' + def.label + '" — signature prévue avant le ' + formaterHorodatageJournal(data.compromisExpireAt));
        }
      } catch (e) {
        console.error('rechercherDossierNotarial : lecture entreprise échouée', def.id, e);
        lecturesEchouees++;
      }
    }
  }

  // Etat final TOUJOURS atteint desormais, quel que soit le nombre de lectures echouees : soit
  // des dossiers sont affiches, soit un message "aucun dossier" explicite -- jamais plus de
  // "Recherche en cours..." qui perdure. Un eventuel echec partiel est signale sans jamais
  // masquer les resultats deja valides trouves par ailleurs.
  let html;
  if (dossiers.length === 0) {
    html = '<div style="font-size:.85rem;color:#8a8060;font-style:italic">Aucun dossier en cours à ce nom.</div>';
  } else {
    html = '<div style="font-size:.85rem;color:#c0b090;margin-bottom:.5rem">Vous avez ' + dossiers.length + ' dossier(s) en attente :</div>';
    html += '<div style="display:flex;flex-direction:column;gap:.3rem">';
    dossiers.forEach(texte => {
      html += '<div style="font-size:.82rem;color:#e0d8c0">• ' + texte + '</div>';
    });
    html += '</div>';
  }
  if (lecturesEchouees > 0) {
    html += '<div style="font-size:.72rem;color:#8a3a20;font-style:italic;margin-top:.6rem">' + lecturesEchouees + ' dossier(s) n\'ont pas pu être consultés (réessayez plus tard) — les résultats ci-dessus restent fiables.</div>';
  }
  resultatsEl.innerHTML = html;
}
async function doOuvrirAchatEntrepot(pa, cost) {
  const buildingId = state.currentBuilding;
  const cur = COUNTRIES[state.country]?.cur || 'FR';
  const etat = (typeof sbGetBatimentEtat === 'function') ? await sbGetBatimentEtat(state.country, state.currentCity, buildingId) : {};
  // RESERVE MILITAIRE (13 septembre 2026) : pendant un Effort de guerre, une part du stock est
  // reservee a l'armement. Elle reste physiquement en entrepot mais n'est plus vendable aux
  // particuliers. On affiche donc le stock REELLEMENT disponible, jamais le stock physique --
  // sans quoi le joueur verrait une quantite qu'il ne pourrait pas acheter.
  const dispoCivil = (typeof stockCivilDisponible === 'function') ? stockCivilDisponible(etat) : null;
  const stock = (dispoCivil && typeof dispoCivil === 'object') ? dispoCivil : (etat.entrepot?.stock || {});
  const prixManuel = etat.entrepot?.prixManuel || {};

  let html = '<div style="padding:1.2rem">';
  html += '<div style="font-size:.96rem;color:#8a8060;margin-bottom:1rem">Indiquez la quantité souhaitée pour chaque produit (laissez vide pour ne rien acheter). Le prix affiché varie selon le niveau du stock.</div>';
  html += '<table style="width:100%;font-size:1rem;border-collapse:collapse">';
  html += '<tr style="color:#8a6a20;font-family:Bebas Neue,sans-serif;font-size:.93rem;letter-spacing:.05em;text-align:left"><th style="padding:.3rem 0">Produit</th><th>Stock</th><th>Prix actuel</th><th>Quantité</th></tr>';

  // §36 : le fournisseur institutionnel ne vend PLUS legalement une categorie interdite en
  // Republia. Le stock n'est jamais supprime (§34) -- il redeviendra vendable de lui-meme des
  // l'abrogation, sans reprise de donnees, puisque la legalite est calculee a la lecture.
  if (typeof rafraichirAssembleeInterdictions === 'function') {
    await rafraichirAssembleeInterdictions().catch(() => null);
  }

  Object.entries(RESSOURCES_ECONOMIE).forEach(([cle, res]) => {
    const enStock = stock[cle] || 0;
    const loiInterdit = (typeof assembleeInterdictionMatiere === 'function')
      ? assembleeInterdictionMatiere(cle) : null;
    const prixActuel = prixManuel[cle] != null ? prixManuel[cle] : (typeof getPrixRessourceEntrepot === 'function' ? getPrixRessourceEntrepot(cle) : res.prixBase);
    const bloque = !!loiInterdit || enStock === 0;
    html += '<tr style="border-top:1px solid #2a2010"' + (loiInterdit ? ' style="opacity:.55"' : '') + '>';
    html += '<td style="padding:.55rem 0"><i class="ti ' + res.icon + '" style="margin-right:.4rem;font-size:1.1rem"></i>' + res.label + '</td>';
    html += '<td style="color:' + (enStock === 0 ? '#cc5540' : '#8a8060') + '">' + enStock + '</td>';
    if (loiInterdit) {
      html += '<td colspan="2" style="color:#cc4444;font-size:.86rem">Vente interdite — « ' + loiInterdit.titre + ' »</td>';
    } else {
      html += '<td style="color:#C9A84C;font-weight:bold">' + prixActuel + ' ' + cur + '</td>';
      html += '<td><input type="number" min="0" max="' + enStock + '" id="achat-entrepot-' + cle + '" style="width:90px;background:#121005;border:1px solid #2a2010;color:#f0ead6;padding:.4rem;font-size:1rem" ' + (bloque ? 'disabled' : '') + ' /></td>';
    }
    html += '</tr>';
  });
  html += '</table>';
  html += '<button class="pnj-action-btn" onclick="confirmerAchatEntrepot(\'' + buildingId + '\',' + pa + ',' + cost + ')" style="margin-top:1.2rem;font-size:1rem;padding:.7rem">Valider l\'achat</button>';
  html += '</div>';

  document.getElementById('postes-modal-title').textContent = 'Salle des Ventes';
  document.getElementById('postes-body').innerHTML = html;
  document.getElementById('modal-postes').classList.add('open');
}
async function ouvrirConsulterEffectifsDouane() {
  const r = await sbDouaneEffectifsPublics().catch(() => null);

  document.getElementById('postes-modal-title').textContent = 'Effectifs des douanes';
  let html = '<div style="padding:1rem">';
  if (!r || r.ok !== true) {
    html += '<div style="font-size:.85rem;color:#cc4444">Consultation impossible — '
         + ((typeof escapeHtmlText === 'function' ? escapeHtmlText(String(r?.raison || '')) : (r?.raison || ''))
            || 'l\'appel n\'a pas abouti') + '.</div></div>';
    document.getElementById('postes-body').innerHTML = html;
    document.getElementById('modal-postes').classList.add('open');
    return;
  }
  const douaniers = r.douaniers || [];
  if (douaniers.length === 0) {
    html += '<div style="font-size:.85rem;color:#8a8060">Aucun douanier en service pour l\'instant.</div>';
  } else {
    html += '<div style="font-size:.8rem;color:#c0b090;margin-bottom:.6rem">' + douaniers.length + ' douanier(s) en service, rattachés au service des douanes du port.</div>';
    douaniers.forEach(d => {
      const label = d.type === 'cynophile' ? (d.matricule + ' — Unité cynophile (' + d.maitreNom + ' & ' + d.chienNom + ')') : d.matricule;
      html += '<div style="font-size:.8rem;color:#8a8060;margin-bottom:.2rem">' + label + '</div>';
    });
  }
  html += '</div>';
  document.getElementById('postes-body').innerHTML = html;
  document.getElementById('modal-postes').classList.add('open');
}
function arrondiPct(v) { return Math.round((v || 0) * 100) / 100; }
async function ouvrirConsulterPort() {
  const port = await getEtatPort();
  const estCommandant = commandantPortValide().ok;

  document.getElementById('postes-modal-title').textContent = 'Administration du Port';
  let html = '<div style="padding:1rem;max-height:70vh;overflow-y:auto">';

  html += '<div style="font-family:Bebas Neue,sans-serif;font-size:.72rem;letter-spacing:.12em;color:#8a6a20;margin-bottom:.4rem">STOCK INSTITUTIONNEL DU PORT</div>';
  const clesStock = RESSOURCES_PORT_IMPORTEES.filter(cle => (port.stock?.[cle] || 0) > 0);
  if (clesStock.length === 0) {
    html += '<div style="font-size:.8rem;color:#8a8060;margin-bottom:.7rem">Aucun stock en attente de répartition.</div>';
  } else {
    clesStock.forEach(cle => {
      const res = RESSOURCES_ECONOMIE[cle];
      html += '<div style="font-size:.8rem;color:#c0b090">' + (res?.label || cle) + ' : ' + Math.round(port.stock[cle]) + '</div>';
    });
    html += '<div style="margin-bottom:.7rem"></div>';
  }

  html += '<div style="font-family:Bebas Neue,sans-serif;font-size:.72rem;letter-spacing:.12em;color:#8a6a20;margin-bottom:.4rem">ORIGINE DES MATIÈRES</div>';
  html += '<div style="font-size:.78rem;color:#8a8060;margin-bottom:.7rem">Bois : 150/jour Scierie Guy Tarembois (Port-Sainte-Marie) + 150/jour Sovarka, soit 300/jour au total — Pétrole brut : 2/3 Al-Khalija, 1/3 Sovarka — Produits exotiques : 100% El Estado.</div>';

  html += '<div style="font-family:Bebas Neue,sans-serif;font-size:.72rem;letter-spacing:.12em;color:#8a6a20;margin-bottom:.4rem">RÉPARTITION NATIONALE ACTUELLE</div>';
  RESSOURCES_PORT_IMPORTEES.forEach(cle => {
    const res = RESSOURCES_ECONOMIE[cle];
    const rep = port.repartition?.[cle] || REPARTITION_PORT_DEFAUT;
    html += '<div style="font-size:.8rem;color:#c0b090;margin-bottom:.2rem">' + (res?.label || cle) + ' — Luthécia ' + arrondiPct(rep.capitale) + '% / Port-Sainte-Marie ' + arrondiPct(rep.ville_a) + '% / Montrouge ' + arrondiPct(rep.ville_b) + '%</div>';
  });
  html += '<div style="margin-bottom:.5rem"></div>';

  html += '<div style="font-family:Bebas Neue,sans-serif;font-size:.72rem;letter-spacing:.12em;color:#8a6a20;margin:.7rem 0 .4rem">ARRIVAGES RÉCENTS</div>';
  const arrivages = (port.arrivages || []).slice(0, 10);
  if (arrivages.length === 0) {
    html += '<div style="font-size:.76rem;color:#8a8060;margin-bottom:.5rem">Aucun arrivage enregistré pour l\'instant.</div>';
  } else {
    arrivages.forEach(a => {
      const res = RESSOURCES_ECONOMIE[a.resource];
      const date = new Date(a.jour);
      // a.label (optionnel, lot Scierie Guy Tarembois du 25 aout 2026) : distingue les deux
      // arrivages reels de bois (Scierie Guy Tarembois vs Sovarka) au lieu d'un seul libelle
      // generique "Bois" -- absent pour toutes les autres ressources, aucun changement ailleurs.
      html += '<div style="font-size:.76rem;color:#8a8060">' + date.toLocaleDateString('fr-FR') + ' — ' + (a.label || res?.label || a.resource) + ' : +' + Math.round(a.qte) + '</div>';
    });
  }

  html += '<div style="font-family:Bebas Neue,sans-serif;font-size:.72rem;letter-spacing:.12em;color:#8a6a20;margin:.7rem 0 .4rem">EXPORTATIONS</div>';
  Object.entries(EXPORTATIONS_PORT_INFOS).forEach(([cle, infos]) => {
    const exp = port.exportations?.[cle];
    if (!exp) { html += '<div style="font-size:.76rem;color:#8a8060">' + infos.label + ' vers ' + infos.destination + ' : aucune donnée pour l\'instant.</div>'; return; }
    html += '<div style="font-size:.8rem;color:#c0b090">' + infos.label + ' vers ' + infos.destination + ' : ' + Math.round(exp.envoye) + '/' + exp.contrat + ' (' + exp.satisfactionPct + '% satisfait)</div>';
  });

  html += '<div style="font-family:Bebas Neue,sans-serif;font-size:.72rem;letter-spacing:.12em;color:#8a6a20;margin:.7rem 0 .4rem">STOCKS DES ENTREPÔTS</div>';
  for (const v of ENTREPOTS_PORT_INFOS) {
    const etatE = await sbGetBatimentEtat('republic', v.city, v.buildingId).catch(() => null);
    const stock = etatE?.entrepot?.stock || {};
    html += '<div style="font-size:.78rem;color:#8a8060;margin-bottom:.2rem">' + v.nom + ' : ' + RESSOURCES_PORT_IMPORTEES.map(cle => (RESSOURCES_ECONOMIE[cle]?.label || cle) + ' ' + Math.round(stock[cle] || 0)).join(', ') + '</div>';
  }

  const caissePort = await chargerCaisseBatiment('republic', BUILDING_ID_PORT).catch(() => ({ solde: 0 }));
  html += '<div style="font-family:Bebas Neue,sans-serif;font-size:.72rem;letter-spacing:.12em;color:#8a6a20;margin:.7rem 0 .4rem">CAISSE DU PORT</div>';
  html += '<div style="font-size:.8rem;color:#c0b090;margin-bottom:.7rem">' + Math.round(caissePort.solde || 0) + ' FR</div>';

  // Correctif UX (25 aout 2026, apres retour de test) : le bouton de modification n'est plus
  // duplique ici -- il vit desormais dans son propre order de salle, "Gérer la logistique
  // nationale" (requiresPost:'capitaine_port', data.js), visible mais grise pour les non-
  // Commandant selon la meme convention que gerer_effectifs_douane/blocus_portuaire, alors que
  // ce panneau de consultation reste volontairement neutre (accessible a tous, aucune action).
  // ouvrirModifierRepartitionPort()/confirmerModifierRepartitionPort() ne sont pas dupliquees :
  // c'est le nouvel order qui les appelle directement (plateau-router.js).
  html += '<div style="margin-top:.5rem;font-size:.76rem;color:#6a5a30;font-style:italic">' +
    (estCommandant
      ? 'Utilisez « Gérer la logistique nationale » (visible dans cette salle) pour modifier la répartition.'
      : 'Seul le Commandant du Port peut modifier la répartition, via « Gérer la logistique nationale ».') +
    '</div>';

  html += '</div>';
  document.getElementById('postes-body').innerHTML = html;
  document.getElementById('modal-postes').classList.add('open');
}
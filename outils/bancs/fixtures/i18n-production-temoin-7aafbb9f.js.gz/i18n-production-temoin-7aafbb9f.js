async function doProduireRecetteCommerceUI(commerceType, buildingId, roomId, recetteId) {
  const pays = state.country || 'republic';
  const ville = state.currentCity || 'capitale';
  const recette = resoudreProduitCommerce(recetteId);
  // Pas de garde PA manuelle ici (trouve en verification post-Lot 1 : ce wrapper bloquait
  // l'action a tort meme sous TEST_MODE=true, en amont de produireRecetteCommerce() qui est
  // elle-meme deja fail-closed via deduireCoutOrdre()). La raison 'pa_insuffisants' est deja
  // geree ci-dessous par le mapping `messages`.
  const res = await produireRecetteCommerce(commerceType, pays, ville, buildingId, roomId, recetteId);
  if (!res.ok) {
    const messages = {
      production_non_autorisee: 'Vous n’êtes pas habilité à produire dans cet établissement.',
      marge_pnj_insuffisante: 'Le coût de ce lot dépasse la marge minimale à 25 FR. Aucun PA ni matière consommé.',
      recette_non_autorisee: 'Cette recette n\'est pas autorisée pour cet établissement.',
      pa_insuffisants: recette.pa + ' PA requis.',
      stock_matiere_insuffisant: 'Il manque du ' + (typeof RESSOURCES_ECONOMIE !== 'undefined' && RESSOURCES_ECONOMIE[res.matiere] ? RESSOURCES_ECONOMIE[res.matiere].label : res.matiere) + ' en stock.',
      caisse_insuffisante: 'L\'établissement ne peut pas payer ce travail actuellement.',
      stock_plein: 'Le stock maximum de ce produit est atteint.',
      introuvable: ''
    };
    showToast('Production impossible', messages[res.raison] || '', false);
    document.getElementById('modal-postes')?.classList.remove('open');
    return;
  }

  updateUI();
  showToast('Production réussie !', recette.label + ' — ' + res.portions + ' portions. +' + res.salaire + ' FR de salaire.', true, true);
  addJournalEntry('Production de ' + recette.label + ' (' + res.portions + ' portions) à ' + (BUILDINGS[buildingId]?.name || buildingId) + '.', 'event-good');
  // Ne ferme pas le modal : rafraichit pour enchainer (meme pattern que confirmerProduction/doProduireArme)
  doConsulterCarteCommerce(commerceType, buildingId, roomId, 0, 0);
}

function texteCommerceMenu(key, original, vars = {}) {
  const translated=typeof window!=='undefined' ? window.RPCommerceMenuI18n?.text?.(key,vars) : null;
  return typeof translated==='string' && translated ? translated :
    original.replace(/\{(\w+)\}/g,(token,k)=>Object.hasOwn(vars,k)?String(vars[k]):token);
}
function nomProduitCommerce(id, original) {
  return (typeof window!=='undefined' && window.RPCommerceMenuI18n?.productLabel?.(id,original)) || original;
}

function actionsCatalogueCommerceHtml(data, commerceType, buildingId, roomId, id) {
  const recette=resoudreProduitCommerce(id);
  const stock=data.stockProduits[id]||0;
  const commander=['restaurant','bar','cafe','brasserie','hotel_restaurant','buvette'].includes(commerceType);
  const args=[commerceType,buildingId,roomId||'',id].map(v=>"'"+v+"'").join(',');
  const peutProduire=commercePeutProduire(data)&&recetteAutoriseePourCommerce(recette,data);
  const style='padding:.45rem .7rem;border:1px solid #526176;border-radius:5px;background:#394656;color:#f2f4f6;';
  const bouton=(action,label,actif)=>'<button '+(actif?'onclick="'+action+'"':'disabled')+' style="'+style+(actif?'cursor:pointer':'opacity:.45')+'">'+label+'</button>';
  return '<div style="display:flex;gap:.4rem;flex-wrap:wrap">'+
    bouton('doCommanderProduitCommerceUI('+args+')',commander?texteCommerceMenu('order','Commander'):texteCommerceMenu('buy','Acheter'),stock>0)+
    bouton('doProduireRecetteCommerceUI('+args+')',texteCommerceMenu('produce','Produire'),peutProduire)+
    bouton('ouvrirFicheProduitCommerce('+args+')',texteCommerceMenu('sheet','Fiche produit'),true)+'</div>';
}

async function doConsulterCarteCommerce(commerceType, buildingId, roomId, pa, cost) {
  const r = await deduireCoutOrdre({ pa, cost });
  if (!r.ok) { showToast(r.raison === 'pa_insuffisants' ? texteCommerceMenu('paInsufficient','PA insuffisants') : texteCommerceMenu('fundsInsufficient','Fonds insuffisants'), '', false); return; }

  const pays = state.country || 'republic';
  const ville = state.currentCity || 'capitale';
  const monnaie = (typeof COUNTRIES !== 'undefined' && COUNTRIES[pays]?.cur) || 'FR';
  const data = await chargerCommerce(commerceType, pays, ville, buildingId, roomId);
  if (!data) { showToast(texteCommerceMenu('unavailable','Indisponible'), '', false); return; }

  document.getElementById('postes-modal-title').textContent = commerceType === 'marche' ? texteCommerceMenu('products','Produits') : texteCommerceMenu('card','Carte');
  let html = '<div style="padding:1rem;background:#151A21;color:#e0e6ed">';
  const carte = data.carte || [];
  const carteValide = carte.filter(id => resoudreProduitCommerce(id));
  if (carteValide.length === 0) {
    html += '<div style="font-size:.9rem;color:#aab5c3">' + texteCommerceMenu('empty','Aucun produit disponible pour le moment.') + '</div>';
  }
  carteValide.forEach(id => {
    const recette = resoudreProduitCommerce(id);
    const stock = data.stockProduits[id] || 0;
    const prix = data.parametres.prixVente[id];
    const composition = Object.entries(recette.materiaux).map(([m, q]) => q + ' ' + (typeof RESSOURCES_ECONOMIE !== 'undefined' && RESSOURCES_ECONOMIE[m] ? RESSOURCES_ECONOMIE[m].label : m)).join(', ');
    const effetsTxt = Object.entries(recette.effets || {}).map(([k, v]) => (v > 0 ? '+' : '') + v + ' ' + k.toUpperCase()).join(', ');
    const enRupture = stock <= 0;
    // La rupture ne bloque que l'achat : ne pas rendre « Produire » visuellement inactif.
    // Ce bouton garde son propre contrôle d'habilitation, sans modifier la transaction.
    html += '<div style="display:flex;gap:.7rem;padding:.6rem;border:1px solid #394656;background:#252D38;border-radius:9px;margin-bottom:.5rem;align-items:center">';
    if (recette.image) html += '<img src="' + recette.image + '" style="width:56px;height:56px;object-fit:cover;border-radius:4px;flex-shrink:0" />';
    html += '<div style="flex:1">';
    html += '<b style="font-size:.93rem;color:#E5C477">' + nomProduitCommerce(id,recette.label) + '</b><br>';
    html += '<span style="font-size:.82rem;color:#aab5c3">' + composition + '</span><br>';
    if (effetsTxt) html += '<span style="font-size:.82rem;color:#6ab858">' + effetsTxt + '</span><br>';
    html += '<span style="font-size:.85rem;color:#C9A84C">' + (prix != null ? prix.toLocaleString('fr-FR') + ' ' + monnaie : texteCommerceMenu('priceUndefined','Prix non défini')) + ' — ' + texteCommerceMenu('stock','Stock : {stock}',{stock}) + '</span>';
    html += '</div>';
    html += actionsCatalogueCommerceHtml(data, commerceType, buildingId, roomId, id);
    html += '</div>';
  });
  html += '</div>';
  document.getElementById('postes-body').innerHTML = html;
  document.getElementById('modal-postes').classList.add('open');
}

// Pont UI <-> logique (commanderProduitCommerce ci-dessus est pure/testable, celle-ci gere
// toasts/journal/rafraichissement, meme separation que confirmerProduction/doProduireArme).
async function doCommanderProduitCommerceUI(commerceType, buildingId, roomId, recetteId) {
  const pays = state.country || 'republic';
  const ville = state.currentCity || 'capitale';
  const monnaie = (typeof COUNTRIES!=='undefined' && COUNTRIES[pays]?.cur) || 'FR';
  const recette = resoudreProduitCommerce(recetteId);
  const res = await commanderProduitCommerce(commerceType, pays, ville, buildingId, roomId, recetteId);
  if (!res.ok) {
    const messages = { rupture: texteCommerceMenu('outOfStock','Ce produit est en rupture de stock.'), fonds_insuffisants: texteCommerceMenu('required','{price} {currency} requis.',{price:res.prix||0,currency:monnaie}), prix_non_defini: texteCommerceMenu('undefinedProductPrice','Prix non défini pour ce produit.'), introuvable: '' };
    if (!res.dejaSignale) showToast(texteCommerceMenu('orderImpossible','Commande impossible'), messages[res.raison] || '', false);
    return;
  }
  updateUI();
  showToast(texteCommerceMenu('served','Commande servie'), nomProduitCommerce(recetteId,recette.label) + '.', true, true);
  addJournalEntry(texteCommerceMenu('orderJournal','{product} commandé(e) — {price} {currency}.',{product:nomProduitCommerce(recetteId,recette.label),price:res.prix,currency:monnaie}), 'event-good');
  // Rafraichit la carte pour permettre d'enchainer sans rouvrir (meme pattern que confirmerProduction/doProduireArme)
  doConsulterCarteCommerce(commerceType, buildingId, roomId, 0, 0);
}

// FICHE OFFICIELLE D'UN PRODUIT EN VENTE (referentiel L2) — protection de l'acheteur.
// GRATUITE : aucun deduireCoutOrdre ici, consulter une fiche n'est pas un ordre. Le
// retour a la carte reutilise doConsulterCarteCommerce avec pa=0/cost=0, exactement
// comme le fait deja doCommanderProduitCommerceUI apres une commande -- donc aucun PA
// n'est preleve deux fois.
// La fiche remplace le contenu de la modale existante plutot que d'ouvrir une seconde
// fenetre : c'est l'idiome deja utilise partout dans ce fichier.
async function ouvrirFicheProduitCommerce(commerceType, buildingId, roomId, recetteId) {
  const pays = state.country || 'republic';
  const ville = state.currentCity || 'capitale';
  const recette = resoudreProduitCommerce(recetteId);
  if (!recette) { showToast(texteCommerceMenu('productMissing','Produit introuvable'), '', false); return; }
  const data = await chargerCommerce(commerceType, pays, ville, buildingId, roomId);
  const cur = COUNTRIES[pays]?.cur || 'FR';

  document.getElementById('postes-modal-title').textContent = texteCommerceMenu('sheetTitle','Fiche du produit');
  document.getElementById('postes-body').innerHTML = '<div style="padding:1rem;color:#8a8060;font-style:italic">' + texteCommerceMenu('loading','Chargement...') + '</div>';
  document.getElementById('modal-postes').classList.add('open');

  // Un produit de marche pousse en inventaire un objet dont `type` vaut l'identifiant de
  // recette : c'est exactement la cle que le resolveur sait lire. On n'invente donc
  // aucune structure, on presente l'objet tel que le jeu le produirait.
  const objet = { type: recetteId };
  if (recette.familleProduitMarche) objet.familleProduitMarche = recette.familleProduitMarche;
  const fiche = typeof sbObjetFicheOfficielle === 'function' ? await sbObjetFicheOfficielle(objet) : null;

  const nomLieu = (typeof BUILDINGS !== 'undefined' && BUILDINGS[buildingId])
    ? (BUILDINGS[buildingId].shortName || BUILDINGS[buildingId].name) : buildingId;

  let html = '<div style="padding:1rem;background:#151A21;color:#e0e6ed">';
  if (recette.image) html += '<img src="' + recette.image + '" style="width:100%;border-radius:4px;margin-bottom:.8rem;max-height:200px;object-fit:cover"/>';
  html += typeof ficheCommercialeHtml === 'function'
    ? ficheCommercialeHtml({
        nom: nomProduitCommerce(recetteId,recette.label),
        description: recette.desc || null,
        prix: (data && data.parametres && data.parametres.prixVente) ? data.parametres.prixVente[recetteId] : null,
        devise: cur,
        vendeur: nomLieu,
        stock: (data && data.stockProduits) ? (data.stockProduits[recetteId] || 0) : null
      })
    : '';
  html += fiche && typeof ficheOfficielleHtml === 'function'
    ? ficheOfficielleHtml(fiche)
    : '<div style="margin-top:.7rem;font-size:.8rem;color:#8a8060;font-style:italic">' + texteCommerceMenu('officialUnavailable','Fiche officielle momentanément indisponible.') + '</div>';
  html += '<button onclick="doConsulterCarteCommerce(\'' + commerceType + '\',\'' + buildingId + '\',\'' + (roomId || '') + '\',0,0)" style="width:100%;margin-top:.9rem;font-family:Bebas Neue,sans-serif;font-size:.75rem;letter-spacing:.08em;padding:.45rem;border:1px solid #3a2a10;background:transparent;color:#C9A84C;cursor:pointer"><i class="ti ti-arrow-left"></i> ' + texteCommerceMenu('back','Retour à la carte') + '</button>';
  html += '</div>';
  document.getElementById('postes-body').innerHTML = html;
}

